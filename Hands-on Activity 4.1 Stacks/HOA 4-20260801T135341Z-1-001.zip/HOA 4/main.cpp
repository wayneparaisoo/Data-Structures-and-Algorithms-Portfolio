#include <iostream>
#include "singlyStack.h"


const size_t maxCap = 100;
int stack[maxCap];
int top = -1, newData, elements;

bool isFull();
bool isEmpty();
void push();
void pop();
void Top();
void displayAll();
void isBalanced(char* expression);

int main(){
    std::cout<<"Stack Using Array: "<<std::endl;
    char expression[15];
    std::cout<<"Enter Expression: ";
    std::cin >> expression;
    std::cout<<"Stack using Lists: "<<std::endl; 
}

bool isEmpty(){
    if(top == -1){
        std::cout<<"Stack Underflow"<<std::endl;
        return true;
    };
    return false;
    }

bool isFull(){
    if(top >= elements){
        std::cout<<"Stack Overflow"<<std::endl;
        return true;
    }
    return false;
}

void push(){

    if(isFull()) return;

    std::cout << "What value do you want to add to the stack?: ";
    std::cin >> newData;
    stack[++top] = newData;
}

void pop(){
    if(isEmpty()) return;

    std::cout<<"Popping: " << stack[top] << std::endl;

    top--;
}

void Top(){
    if(isEmpty()) return;

    std::cout << "The top element is: "<< stack[top] << std::endl;
}

void displayAll(){
    if(isEmpty()) return;

    std::cout<< "The elements inside the stack are: "<< std::endl;
    for(int i = top; i >= 0; i--){  
        std::cout << stack[i] << std::endl;
    }
}

bool isBalanced(char* expression){
    char delims[6] = {'[',']','(',')','{','}'};
    for(int i = 0; i <= 6; i++){
        if(expression == delims[i]){
            if(expression != delims[i+1]){
                std::cout<<"Expression is invalid\n";
            }
            else{
                std::cout<<"Expression is Valid and Balanced";
            }
        }
    }
    return;
}